package com.simplilearn.project1;

import java.util.Scanner;

public class ArithmeticCalculator {

	public static void main(String[] args) {
		double number1;
		double number2;
		double result;
		byte choice=0;
		Scanner sc= new Scanner(System.in);
		
		System.out.println("ARITHMETIC CALCULATOR");
		System.out.println("Press 1 to ADD:");
		System.out.println("Press 2 to SUBSTRACT:");
		System.out.println("Press 3 to MULTIPLY:");
		System.out.println("Press 4 to DIVIDE:");
		System.out.println("Press 5 to MODULO:");
		
		choice =sc.nextByte();
		
		System.out.println("Enter First Number:");
		number1=sc.nextDouble();
		System.out.println("Enter Second Number:");
		number2=sc.nextDouble();
		
		if(choice==1)
		{
			result=number1+number2;
			System.out.println("The Addition is:"+result);
		}
		else if(choice==2)
		{
			result=number1-number2;
			System.out.println("The Substraction is:"+result);
		}
		else if(choice==3)
		{
			result=number1*number2;
			System.out.println("The Multiplication is:"+result);
		}
		else if(choice==4)
		{
			result=number1/number2;
			System.out.println("The Division is:"+result);
		}
		else if(choice==5)
		{
			result=number1%number2;
			System.out.println("The Modulo is:"+result);
		}
		else
		{
			System.out.println("sorry invalid choice");
		}
		
	}

}
